#version 330
flat out int cn_scope_mask;
flat out int cn_grenade_overlay;
flat out vec2 cn_grenade_strength;
#moj_import<minecraft:fog.glsl>
#moj_import<minecraft:dynamictransforms.glsl>
#moj_import<minecraft:projection.glsl>
#moj_import<minecraft:globals.glsl>
in vec3 Position;in vec4 Color;in vec2 UV0;in ivec2 UV2;uniform sampler2D Sampler2;out float sphericalVertexDistance;out float cylindricalVertexDistance;out vec4 vertexColor;out vec2 texCoord0;
#moj_import<_03855dff6cd4bd1e.glsl>
#moj_import<_936192c41a938c27.glsl>
#moj_import<_eb47fa99ed5eef4e.glsl>
#moj_import<_c4903960d9a5ea7d.glsl>
#moj_import<_2b33885594154252.glsl>
#moj_import<_5e6b86de6e8cd149.glsl>
#moj_import<_a24a0d1f147e4e10.glsl>
#moj_import<_5bb838b6a2bf0157.glsl>
#moj_import<_f56356d0b826cd5d.glsl>
const float _cn_tab_panel_width=426.0;
const float _cn_tab_panel_height=180.0;
const float _cn_tab_source_top=10.0;
const float _cn_tab_source_width=440.0;
const float _cn_tab_source_content_offset=0.0;
const float _cn_tab_color_eps=0.002;
const float _cn_tab_line_y_offset=0.0;
const float _cn_tab_text_y_offset=2.0;
const float _cn_tab_score_y_offset=0.0;
const float _cn_tab_header_y_offset=-3.0;
const float _cn_tab_marker_red=0.007843;

bool _cn_tab_near(vec4 c,vec3 rgb){
    return abs(c.r-rgb.r)<=_cn_tab_color_eps&&abs(c.g-rgb.g)<=_cn_tab_color_eps&&abs(c.b-rgb.b)<=_cn_tab_color_eps;
}

bool _cn_tab_surface(vec4 c){
    return _cn_tab_near(c,vec3(0.070588,0.996078,0.203922));
}

bool _cn_tab_marker(vec4 c){
    return c.a>=0.95&&abs(c.r-_cn_tab_marker_red)<=_cn_tab_color_eps;
}

int _cn_tab_marker_kind(vec4 c){
    return int(floor(c.g*255.0+0.5));
}

float _cn_tab_marker_y(vec4 c){
    return floor(c.b*255.0+0.5);
}

bool _cn_tab_marker_text_kind(int k){
    return k==2||k==3||k==4||k==5||k==6||k==10||k==11||k==12||k==13||k==14||k==15||(k>=16&&k<=24);
}

float _cn_tab_timeline_alpha(int k){
    if(k==17)return 0.86;
    if(k==18)return 0.72;
    if(k==19)return 0.60;
    if(k==20)return 0.49;
    if(k==21)return 0.39;
    if(k==22)return 0.30;
    if(k==23)return 0.23;
    if(k==24)return 0.17;
    return 1.0;
}

bool _cn_tab_marker_score_kind(int k){
    return k==8||k==9;
}

bool _cn_tab_text(vec4 c){
    return _cn_tab_near(c,vec3(0.603922,0.788235,0.964706))
        ||_cn_tab_near(c,vec3(0.713725,0.623529,0.403922))
        ||_cn_tab_near(c,vec3(0.874510,0.909804,0.462745))
        ||_cn_tab_near(c,vec3(0.588235,0.588235,0.580392))
        ||_cn_tab_near(c,vec3(0.254902,0.254902,0.254902));
}

bool _cn_tab_color(vec4 c){
    if(c.a<0.95)return false;
    return _cn_tab_marker(c)
        ||_cn_tab_near(c,vec3(0.996078,0.992157,0.984314))
        ||_cn_tab_text(c)
        ||_cn_tab_surface(c);
}

vec4 _cn_tab_visual(vec4 c){
    vec4 r=c;
    if(_cn_tab_marker(c)){
        int k=_cn_tab_marker_kind(c);
        if(k==2){
            r.rgb=vec3(0.772549,0.823529,0.890196);
        }else if(k==3){
            r.rgb=vec3(0.956863,0.843137,0.615686);
        }else if(k==4){
            r.rgb=vec3(0.870588,0.905882,0.458824);
        }else if(k==5){
            r.rgb=vec3(0.584314,0.584314,0.576471);
        }else if(k==6){
            r.rgb=vec3(0.250980,0.250980,0.250980);
        }else if(k==8){
            r.rgb=vec3(0.772549,0.823529,0.890196);
        }else if(k==9){
            r.rgb=vec3(0.956863,0.843137,0.615686);
        }else if(k==10){
            r.rgb=vec3(0.352941,0.345098,0.349020);
        }else if(k==11){
            r.rgb=vec3(0.482353,0.419608,0.290196);
        }else if(k==13){
            r.rgb=vec3(0.905882,0.866667,0.831373);
        }else if(k==14){
            r.rgb=vec3(0.941176,1.0,1.0);
        }else if(k==15){
            r.rgb=vec3(1.0,1.0,0.811765);
        }else{
            r.rgb=vec3(1.0,1.0,1.0);
        }
        if(k>=16&&k<=24){
            r.a*=_cn_tab_timeline_alpha(k);
        }
    }else if(_cn_tab_near(c,vec3(0.996078,0.992157,0.984314))){
        r.rgb=vec3(1.0,1.0,1.0);
    }else if(_cn_tab_near(c,vec3(0.603922,0.788235,0.964706))){
        r.rgb=vec3(0.772549,0.823529,0.890196);
    }else if(_cn_tab_near(c,vec3(0.713725,0.623529,0.403922))){
        r.rgb=vec3(0.956863,0.843137,0.615686);
    }else if(_cn_tab_near(c,vec3(0.874510,0.909804,0.462745))){
        r.rgb=vec3(0.870588,0.905882,0.458824);
    }else if(_cn_tab_near(c,vec3(0.588235,0.588235,0.580392))){
        r.rgb=vec3(0.584314,0.584314,0.576471);
    }else if(_cn_tab_near(c,vec3(0.254902,0.254902,0.254902))){
        r.rgb=vec3(0.250980,0.250980,0.250980);
    }else if(_cn_tab_surface(c)){
        r.rgb=vec3(1.0,1.0,1.0);
    }
    return r;
}

bool _cn_tab_vertex(vec3 p,vec2 guiSize,vec4 c){
    return _cn_tab_color(c);
}

vec3 _cn_tab_center(vec3 p,vec2 guiSize){
    vec2 s=abs(guiSize);
    float targetLeft=max(0.0,(s.x-_cn_tab_panel_width)*0.5);
    float sourceLeft=max(0.0,(s.x-_cn_tab_source_width)*0.5)+_cn_tab_source_content_offset;
    float targetTop=max(0.0,(s.y-_cn_tab_panel_height)*0.5);
    p.x+=targetLeft-sourceLeft;
    p.y+=targetTop-_cn_tab_source_top;
    return p;
}

vec3 _cn_tab_offsets(vec3 p,vec4 c){
    if(_cn_tab_marker(c)){
        int k=_cn_tab_marker_kind(c);
        float y=_cn_tab_marker_y(c);
        if(k==1){
            p.y+=y+_cn_tab_line_y_offset;
        }else if(k==13){
            p.y+=y+_cn_tab_text_y_offset+_cn_tab_header_y_offset;
        }else if(_cn_tab_marker_text_kind(k)){
            p.y+=y+_cn_tab_text_y_offset;
        }else if(_cn_tab_marker_score_kind(k)){
            p.y+=y+_cn_tab_score_y_offset;
        }else{
            p.y+=y;
        }
    }else if(_cn_tab_surface(c)){
        p.y+=_cn_tab_line_y_offset;
    }else if(_cn_tab_text(c)){
        p.y+=_cn_tab_text_y_offset;
    }
    return p;
}
out vec3 vertexPosition;out vec2 _b706723963a8563c;flat out int _5745e4143a817804;void cn_original_text_main(){gl_Position=ProjMat*ModelViewMat*vec4(Position,1.0);sphericalVertexDistance=fog_spherical_distance(Position);cylindricalVertexDistance=fog_cylindrical_distance(Position);vertexColor=Color*texelFetch(Sampler2,UV2/16,0);texCoord0=UV0;if(_6aaf116dfa780a4f(Position.y)<=-2000){vec3 _143707a42f1f0bdf=Position;int _55471531b473c20f=(_6aaf116dfa780a4f(Position.y)+2000)/-1000;_143707a42f1f0bdf.y+=(_55471531b473c20f*1000)+2500;if(_55471531b473c20f==0){sphericalVertexDistance=fog_spherical_distance(_143707a42f1f0bdf);cylindricalVertexDistance=fog_cylindrical_distance(_143707a42f1f0bdf);gl_Position=ProjMat*vec4(_143707a42f1f0bdf,1.0);gl_Position.z*=0.1;}else if(_55471531b473c20f==1){sphericalVertexDistance=fog_spherical_distance(_143707a42f1f0bdf);cylindricalVertexDistance=fog_cylindrical_distance(_143707a42f1f0bdf);vertexColor.a=0.25;gl_Position=ProjMat*ModelViewMat*vec4(_143707a42f1f0bdf,1.0);}else if(_55471531b473c20f==2){sphericalVertexDistance=fog_spherical_distance(_143707a42f1f0bdf);cylindricalVertexDistance=fog_cylindrical_distance(_143707a42f1f0bdf);vertexColor.a=0.5;gl_Position=ProjMat*ModelViewMat*vec4(_143707a42f1f0bdf,1.0);}else if(_55471531b473c20f==3){sphericalVertexDistance=fog_spherical_distance(_143707a42f1f0bdf);cylindricalVertexDistance=fog_cylindrical_distance(_143707a42f1f0bdf);vertexColor.a=0.75;gl_Position=ProjMat*ModelViewMat*vec4(_143707a42f1f0bdf,1.0);}return;}vertexPosition=Position;_b706723963a8563c=_9f16cbf13d7be175(ProjMat);_5745e4143a817804=0;if(_cn_tab_vertex(vertexPosition,_b706723963a8563c,Color)){vertexPosition=_cn_tab_center(vertexPosition,_b706723963a8563c);vertexPosition=_cn_tab_offsets(vertexPosition,Color);sphericalVertexDistance=fog_spherical_distance(vertexPosition);cylindricalVertexDistance=fog_cylindrical_distance(vertexPosition);vertexColor=_cn_tab_visual(Color)*texelFetch(Sampler2,UV2/16,0);gl_Position=ProjMat*ModelViewMat*vec4(vertexPosition,1.0);}{int _1cede1cb72a9521f=_6aaf116dfa780a4f(_b706723963a8563c.y-Position.y);if(Color.a !=0.0 && _1cede1cb72a9521f<=-100000){int _55471531b473c20f=(_1cede1cb72a9521f+100000)/-10000;vertexPosition.y+=(_55471531b473c20f*-10000)-105000;_cf40eb8c75feea6d _7cb5762a773b0371=_cf40eb8c75feea6d(vertexPosition,Color,_5745e4143a817804);_77ca61b50683f456 _e1c65da076aa4a5e=_77ca61b50683f456(gl_VertexID % 4,_b706723963a8563c,mat3(0),GameTime,ScreenSize);switch(_55471531b473c20f){case 1:_7cb5762a773b0371=_d3b8eb27f7be65cd(_7cb5762a773b0371,_e1c65da076aa4a5e);break;case 2:_7cb5762a773b0371=_d3b8eb27f7be65cd(_7cb5762a773b0371,_e1c65da076aa4a5e);_7cb5762a773b0371=_5798ca997abd21c6(_7cb5762a773b0371,_e1c65da076aa4a5e,0,-1);break;case 3:_7cb5762a773b0371=_d3b8eb27f7be65cd(_7cb5762a773b0371,_e1c65da076aa4a5e);_7cb5762a773b0371=_5798ca997abd21c6(_7cb5762a773b0371,_e1c65da076aa4a5e,-0.5,-1);break;case 4:_7cb5762a773b0371=_d3b8eb27f7be65cd(_7cb5762a773b0371,_e1c65da076aa4a5e);_7cb5762a773b0371=_5798ca997abd21c6(_7cb5762a773b0371,_e1c65da076aa4a5e,-0.5,-1);_7cb5762a773b0371=_d9969c3edb40a275(_7cb5762a773b0371,_e1c65da076aa4a5e,0.5);break;case 5:_7cb5762a773b0371=_d3b8eb27f7be65cd(_7cb5762a773b0371,_e1c65da076aa4a5e);_7cb5762a773b0371=_5798ca997abd21c6(_7cb5762a773b0371,_e1c65da076aa4a5e,0.5,-1);break;case 6:_7cb5762a773b0371=_d3b8eb27f7be65cd(_7cb5762a773b0371,_e1c65da076aa4a5e);_7cb5762a773b0371=_5798ca997abd21c6(_7cb5762a773b0371,_e1c65da076aa4a5e,0,-0.5);break;case 7:_7cb5762a773b0371=_d3b8eb27f7be65cd(_7cb5762a773b0371,_e1c65da076aa4a5e);_7cb5762a773b0371=_5798ca997abd21c6(_7cb5762a773b0371,_e1c65da076aa4a5e,-0.5,-0.5);break;case 8:_7cb5762a773b0371=_d3b8eb27f7be65cd(_7cb5762a773b0371,_e1c65da076aa4a5e);_7cb5762a773b0371=_5798ca997abd21c6(_7cb5762a773b0371,_e1c65da076aa4a5e,0,-0.25);break;case 9:_7cb5762a773b0371=_d3b8eb27f7be65cd(_7cb5762a773b0371,_e1c65da076aa4a5e);_7cb5762a773b0371=_5798ca997abd21c6(_7cb5762a773b0371,_e1c65da076aa4a5e,-0.5,0);break;case 10:_7cb5762a773b0371=_d3b8eb27f7be65cd(_7cb5762a773b0371,_e1c65da076aa4a5e);_7cb5762a773b0371=_5798ca997abd21c6(_7cb5762a773b0371,_e1c65da076aa4a5e,0.5,0);break;case 11:_7cb5762a773b0371=_d3b8eb27f7be65cd(_7cb5762a773b0371,_e1c65da076aa4a5e);_7cb5762a773b0371=_5798ca997abd21c6(_7cb5762a773b0371,_e1c65da076aa4a5e,0.5,0);_7cb5762a773b0371=_d9969c3edb40a275(_7cb5762a773b0371,_e1c65da076aa4a5e,0.5);break;case 12:_7cb5762a773b0371=_5798ca997abd21c6(_7cb5762a773b0371,_e1c65da076aa4a5e,-0.5,0);_7cb5762a773b0371=_1753527f366fe2f1(_7cb5762a773b0371,_e1c65da076aa4a5e);_7cb5762a773b0371=_5798ca997abd21c6(_7cb5762a773b0371,_e1c65da076aa4a5e,0.5,-0.5);break;case 13:_7cb5762a773b0371=_5798ca997abd21c6(_7cb5762a773b0371,_e1c65da076aa4a5e,-0.5,0);_7cb5762a773b0371=_d3b8eb27f7be65cd(_7cb5762a773b0371,_e1c65da076aa4a5e);_7cb5762a773b0371=_7ddbb5286b70e34b(_7cb5762a773b0371,_e1c65da076aa4a5e);_7cb5762a773b0371=_1753527f366fe2f1(_7cb5762a773b0371,_e1c65da076aa4a5e);_7cb5762a773b0371=_5798ca997abd21c6(_7cb5762a773b0371,_e1c65da076aa4a5e,0.5,-0.5);break;case 14:_7cb5762a773b0371=_76a13e747705ff91(_7cb5762a773b0371,_e1c65da076aa4a5e);break;case 15:_7cb5762a773b0371=_e2fb0715acd9225f(_7cb5762a773b0371,_e1c65da076aa4a5e);break;case 16:_7cb5762a773b0371=_c1df219c2f1ca5fa(_7cb5762a773b0371,_e1c65da076aa4a5e);break;case 17:_7cb5762a773b0371=_5798ca997abd21c6(_7cb5762a773b0371,_e1c65da076aa4a5e,-0.5,0);_7cb5762a773b0371=_1753527f366fe2f1(_7cb5762a773b0371,_e1c65da076aa4a5e);_7cb5762a773b0371=_5798ca997abd21c6(_7cb5762a773b0371,_e1c65da076aa4a5e,0.5,-0.5);_7cb5762a773b0371=_a0cbe56eb4975f38(_7cb5762a773b0371,_e1c65da076aa4a5e);break;case 18:_7cb5762a773b0371=_5798ca997abd21c6(_7cb5762a773b0371,_e1c65da076aa4a5e,-0.5,0);_7cb5762a773b0371=_1753527f366fe2f1(_7cb5762a773b0371,_e1c65da076aa4a5e);_7cb5762a773b0371=_5798ca997abd21c6(_7cb5762a773b0371,_e1c65da076aa4a5e,0.5,-0.5);_7cb5762a773b0371=_8b694e3bfa8cdd23(_7cb5762a773b0371,_e1c65da076aa4a5e);break;case 19:_7cb5762a773b0371=_5798ca997abd21c6(_7cb5762a773b0371,_e1c65da076aa4a5e,0,-0.5);break;case 20:_7cb5762a773b0371=_cddd16cc52034b43(_7cb5762a773b0371,_e1c65da076aa4a5e);_7cb5762a773b0371=_5798ca997abd21c6(_7cb5762a773b0371,_e1c65da076aa4a5e,-0.5,0);break;case 21:_7cb5762a773b0371=_82a55857ccb8e506(_7cb5762a773b0371,_e1c65da076aa4a5e);_7cb5762a773b0371=_5798ca997abd21c6(_7cb5762a773b0371,_e1c65da076aa4a5e,-0.5,0);break;case 22:_7cb5762a773b0371=_5798ca997abd21c6(_7cb5762a773b0371,_e1c65da076aa4a5e,-0.5,0);break;}vertexPosition=_7cb5762a773b0371._3a20231732d8657a;vertexColor=_7cb5762a773b0371._66632d080046c728*texelFetch(Sampler2,UV2/16,0);_5745e4143a817804=_7cb5762a773b0371._5745e4143a817804;gl_Position=ProjMat*ModelViewMat*vec4(vertexPosition,1.0);return;}}}

void main() {
    cn_original_text_main();
    cn_scope_mask = 0;
    cn_grenade_overlay = 0;
    cn_grenade_strength = vec2(0.0);
    ivec3 cn_rgb = ivec3(round(Color.rgb * 255.0));
    // Reserved GUI marker, rendered by the title layer AFTER the game HUD.
    // Titles always draw a shadow. Suppress that quad explicitly: letting it
    // take the ordinary text path leaves a dark square at the screen centre.
    if (abs(ProjMat[3][3]) > 0.5 && cn_rgb.r == 1 && cn_rgb.g == 4 && cn_rgb.b >= 4 && cn_rgb.b <= 36) {
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
        vertexColor = vec4(0.0);
        return;
    }
    if (abs(ProjMat[3][3]) > 0.5 && cn_rgb.r == 5 && cn_rgb.g == 16 && cn_rgb.b >= 16 && cn_rgb.b <= 143) {
        cn_grenade_overlay = 5;
        cn_grenade_strength = vec2(float(cn_rgb.b - 16) / 127.0, 0.0);
        int corner = gl_VertexID % 4;
        vec2 p = vec2(corner < 2 ? -1.0 : 1.0, (corner == 0 || corner == 3) ? 1.0 : -1.0);
        gl_Position = vec4(p, -0.99, 1.0);
    }
    if (abs(ProjMat[3][3]) < 0.001 && cn_rgb.r == 3 && cn_rgb.g == 5 && cn_rgb.b >= 7 && cn_rgb.b <= 9) {
        cn_grenade_overlay = cn_rgb.b - 6;
        cn_grenade_strength = vec2(cn_grenade_overlay == 2 ? 0.0 : Color.a, cn_grenade_overlay == 1 ? 0.0 : 1.0);
        int corner = gl_VertexID % 4;
        vec2 p = vec2(corner < 2 ? -1.0 : 1.0, (corner == 0 || corner == 3) ? -1.0 : 1.0);
        // Text pipelines cull back faces: screen-space winding must be CCW.
        p.y = -p.y;
        gl_Position = vec4(p, -0.99, 1.0);
        vertexColor.a = Color.a;
    }
    if (abs(ProjMat[3][3]) < 0.001 && cn_rgb.r == 4 && cn_rgb.g >= 16 && cn_rgb.g <= 143 && cn_rgb.b >= 16 && cn_rgb.b <= 143) {
        cn_grenade_overlay = 4;
        cn_grenade_strength = vec2(float(cn_rgb.b - 16), float(cn_rgb.g - 16)) / 127.0;
        int corner = gl_VertexID % 4;
        vec2 p = vec2(corner < 2 ? -1.0 : 1.0, (corner == 0 || corner == 3) ? -1.0 : 1.0);
        p.y = -p.y;
        gl_Position = vec4(p, -0.99, 1.0);
    }
    if (abs(ProjMat[3][3]) < 0.001 && Color.a > 0.9 && all(equal(ivec3(round(Color.rgb * 255.0)), ivec3(2,4,6)))) {
        cn_scope_mask = 1;
        int corner = gl_VertexID % 4;
        vec2 p = vec2(corner < 2 ? -1.0 : 1.0, (corner == 0 || corner == 3) ? -1.0 : 1.0);
        gl_Position = vec4(p, -1.0, 1.0);
    }
}
