#version 330
flat in int cn_scope_mask;
flat in int cn_grenade_overlay;
flat in vec2 cn_grenade_strength;
#moj_import<minecraft:fog.glsl>
#moj_import<minecraft:dynamictransforms.glsl>
#moj_import<minecraft:globals.glsl>
uniform sampler2D Sampler0;in float sphericalVertexDistance;in float cylindricalVertexDistance;in vec4 vertexColor;in vec2 texCoord0;out vec4 fragColor;
#moj_import<_eb47fa99ed5eef4e.glsl>
#moj_import<_936192c41a938c27.glsl>
in vec3 vertexPosition;in vec2 _b706723963a8563c;flat in int _5745e4143a817804;vec4 _5b80fa9c37fb9fcf(vec4 _51c8f6838f39b0a8,vec4 _e002e23cd0813114,vec4 _26061e37a1730c15,vec4 _1b279ebec3bd4482,vec2 _39e28868faf61c47){vec4 _176166031685a938=mix(_51c8f6838f39b0a8,_e002e23cd0813114,_39e28868faf61c47.x);vec4 _92f9d3c738b83291=mix(_26061e37a1730c15,_1b279ebec3bd4482,_39e28868faf61c47.x);return mix(_176166031685a938,_92f9d3c738b83291,_39e28868faf61c47.y);}void cn_original_text_main(){vec4 _66632d080046c728=texture(Sampler0,texCoord0)*vertexColor*ColorModulator;if(_66632d080046c728.a<0.001){discard;}fragColor=apply_fog(_66632d080046c728,sphericalVertexDistance,cylindricalVertexDistance,FogEnvironmentalStart,FogEnvironmentalEnd,FogRenderDistanceStart,FogRenderDistanceEnd,FogColor);vec2 _059cfeea21b75e2c=texCoord0.xy;vec2 _8e660360f3f274cf=1.0/textureSize(Sampler0,0);vec2 _8e98faa0dc5ba0b4=_059cfeea21b75e2c*textureSize(Sampler0,0)-0.5;vec2 _51c8f6838f39b0a8=floor(_8e98faa0dc5ba0b4)+0.5;vec2 _26061e37a1730c15=_51c8f6838f39b0a8+vec2(0.0,1.0);vec2 _e002e23cd0813114=_51c8f6838f39b0a8+vec2(1.0,0.0);vec2 _1b279ebec3bd4482=_51c8f6838f39b0a8+vec2(1.0,1.0);if(_5745e4143a817804>0){if(_5745e4143a817804==2){vec4 _b58da64abfdfdaf3=texture(Sampler0,_51c8f6838f39b0a8*_8e660360f3f274cf);vec4 _d9e03b7b57ed515f=texture(Sampler0,_26061e37a1730c15*_8e660360f3f274cf);vec4 _7e10ccd1d29da96e=texture(Sampler0,_e002e23cd0813114*_8e660360f3f274cf);vec4 _33dd33a04b3fd492=texture(Sampler0,_1b279ebec3bd4482*_8e660360f3f274cf);vec2 _39e28868faf61c47=fract(_8e98faa0dc5ba0b4);_66632d080046c728=_5b80fa9c37fb9fcf(_b58da64abfdfdaf3,_7e10ccd1d29da96e,_d9e03b7b57ed515f,_33dd33a04b3fd492,_39e28868faf61c47)*vertexColor*ColorModulator;}else if(_5745e4143a817804==10){vec2 _c1117be303cc7b15=vec2(_b706723963a8563c.x-16-64,16+64);if(!_aaff1925cd935342(vertexPosition.xy,_c1117be303cc7b15,62))_66632d080046c728=vec4(0);}else if(_5745e4143a817804==11){vec2 _c1117be303cc7b15=vec2(16+64,16+64);if(!_aaff1925cd935342(vertexPosition.xy,_c1117be303cc7b15,62))_66632d080046c728=vec4(0);}if(_66632d080046c728.a<0.1){discard;}fragColor=apply_fog(_66632d080046c728,sphericalVertexDistance,cylindricalVertexDistance,FogEnvironmentalStart,FogEnvironmentalEnd,FogRenderDistanceStart,FogRenderDistanceEnd,FogColor);return;}}
void main() {
    if (cn_grenade_overlay > 0) {
        float flash = clamp(cn_grenade_strength.x, 0.0, 1.0);
        float smoke = clamp(cn_grenade_strength.y, 0.0, 1.0);
        float opacity = flash + smoke * (1.0 - flash);
        if (opacity < 0.001) discard;
        vec3 premultiplied = vec3(flash + 0.58 * smoke * (1.0 - flash));
        fragColor = vec4(premultiplied / opacity, opacity);
        return;
    }
    if (cn_scope_mask == 1) {
        vec2 pixel = gl_FragCoord.xy - ScreenSize * 0.5;
        float radius = length(pixel) / ScreenSize.y;
        float rim = smoothstep(0.465, 0.472, radius);
        float reticle = 1.0 - smoothstep(0.45, 0.9, min(abs(pixel.x), abs(pixel.y)));
        float opacity = max(rim, reticle * 0.92);
        if (opacity < 0.001) discard;
        fragColor = vec4(0.0, 0.0, 0.0, opacity);
        return;
    }
    cn_original_text_main();
}
