#version 330

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl with CounterNeft GUI filters.
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};

in vec4 vertexColor;
in vec2 cnGuiPos;
in vec2 cnGuiSize;

out vec4 fragColor;

const bool CN_DIALOG_FOCUS_ENABLED = true;
const bool CN_DIALOG_FOCUS_DEBUG = false;
const float CN_DIALOG_FOCUS_HALF_WIDTH = 214.000;
const float CN_DIALOG_FOCUS_HALF_HEIGHT = 253.000;
const float CN_DIALOG_FOCUS_MIN_RGB = 0.98;
const float CN_DIALOG_FOCUS_MIN_ALPHA = 0.25;
const float CN_TAB_CENTER_HALF_WIDTH = 384.0;
const float CN_TAB_MIN_Y = 4.0;
const float CN_TAB_MAX_Y = 260.0;
const float CN_COLOR_EPS = 0.006;

bool cn_near(float value, float target) {
    return abs(value - target) <= CN_COLOR_EPS;
}

bool cn_is_buy_dialog_focus(vec4 color) {
    if (!CN_DIALOG_FOCUS_ENABLED) {
        return false;
    }
    bool nearWhite = color.r >= CN_DIALOG_FOCUS_MIN_RGB
        && color.g >= CN_DIALOG_FOCUS_MIN_RGB
        && color.b >= CN_DIALOG_FOCUS_MIN_RGB
        && color.a >= CN_DIALOG_FOCUS_MIN_ALPHA;
    vec2 center = cnGuiSize * 0.5;
    bool inBuyMenuBand = abs(cnGuiPos.x - center.x) <= CN_DIALOG_FOCUS_HALF_WIDTH
        && abs(cnGuiPos.y - center.y) <= CN_DIALOG_FOCUS_HALF_HEIGHT;
    return nearWhite && inBuyMenuBand;
}

bool cn_is_vanilla_tab_background(vec4 color) {
    bool inTabBand = abs(cnGuiPos.x - cnGuiSize.x * 0.5) <= CN_TAB_CENTER_HALF_WIDTH
        && cnGuiPos.y >= CN_TAB_MIN_Y
        && cnGuiPos.y <= CN_TAB_MAX_Y;
    if (!inTabBand) {
        return false;
    }

    bool panel = cn_near(color.r, 0.0)
        && cn_near(color.g, 0.0)
        && cn_near(color.b, 0.0)
        && cn_near(color.a, 128.0 / 255.0);
    bool row = color.r >= 0.98
        && color.g >= 0.98
        && color.b >= 0.98
        && color.a >= 0.04
        && color.a <= 0.45;
    return panel || row;
}

void main() {
    vec4 color = vertexColor;
    if (color.a == 0.0) {
        discard;
    }

    vec4 outputColor = color * ColorModulator;
    if (cn_is_buy_dialog_focus(outputColor)) {
        if (CN_DIALOG_FOCUS_DEBUG) {
            fragColor = vec4(1.0, 0.0, 1.0, 1.0);
            return;
        }
        discard;
    }

    if (cn_is_vanilla_tab_background(color) || cn_is_vanilla_tab_background(outputColor)) {
        discard;
    }

    fragColor = outputColor;
}
