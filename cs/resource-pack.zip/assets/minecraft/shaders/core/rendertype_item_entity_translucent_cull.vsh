#version 330
#moj_import<minecraft:light.glsl>
#moj_import<minecraft:fog.glsl>
#moj_import<minecraft:dynamictransforms.glsl>
#moj_import<minecraft:projection.glsl>
#moj_import<minecraft:globals.glsl>
in vec3 Position;in vec4 Color;in vec2 UV0;in vec2 UV1;in ivec2 UV2;in vec3 Normal;uniform sampler2D Sampler2;out float sphericalVertexDistance;out float cylindricalVertexDistance;out vec4 vertexColor;out vec2 texCoord0;out vec2 texCoord1;out vec2 texCoord2;
#moj_import<_03855dff6cd4bd1e.glsl>
#moj_import<_936192c41a938c27.glsl>
#moj_import<_936192c41a938c27.glsl>
#moj_import<counterneft_camera_trail.glsl>
#moj_import<counterneft_inferno.glsl>
#moj_import<counterneft_first_person_guard.glsl>
void counterneft_legacy_main();
// Only CounterNeft smoke uses this tint signature (R=G+4, B=G-4).
// A color tag is used because the vanilla item shader has no per-model uniform.
bool counterneft_smoke_vertex() {
    ivec4 tint = ivec4(floor(Color * 255.0 + 0.5));
    return tint.a == 255 && tint.g >= 184 && tint.g <= 216
        && tint.r - tint.g == 4 && tint.g - tint.b == 4;
}
void main() {
    counterneft_legacy_main();
    bool cn_fire = cn_inferno_vertex();
    if (cn_first_person_guard_vertex()) return;
    if (cn_fire) return;
    if (counterneft_smoke_vertex()) {
        // Bypass minecraft_mix_light(..., Normal, ...), which makes the cube's
        // underside darker even when the display has brightness 15/15.
        float grey = Color.g;
        // The lighter rim is more translucent; the denser core remains readable.
        float rim = clamp((grey * 255.0 - 184.0) / 32.0, 0.0, 1.0);
        float opacity = mix(1.0, 0.72, rim);
        vertexColor = vec4(grey, grey, grey, Color.a * opacity) * texelFetch(Sampler2, UV2 / 16, 0);
    }
    // Transient HE dust: separate tint signature, with a 4-bit fade bucket.
    ivec4 dustTint = ivec4(floor(Color * 255.0 + 0.5));
    int dustFade = dustTint.g - dustTint.b - 5;
    if (dustTint.a == 255 && dustTint.g >= 96 && dustTint.g <= 152
        && dustTint.r - dustTint.g == 5 && dustFade >= 0 && dustFade <= 15) {
        vertexColor = vec4(vec3(Color.g), 1.0 - float(dustFade) / 15.0) * texelFetch(Sampler2, UV2 / 16, 0);
    }
    vec3 cameraPosition;
    if (counterneft_camera_trail(Position, cameraPosition)) {
        gl_Position = ProjMat * vec4(cameraPosition, 1.0);
        sphericalVertexDistance = fog_spherical_distance(cameraPosition);
        cylindricalVertexDistance = fog_cylindrical_distance(cameraPosition);
    }
}
#define main counterneft_legacy_main
void main(){gl_Position=ProjMat*ModelViewMat*vec4(Position,1.0);sphericalVertexDistance=fog_spherical_distance(Position);cylindricalVertexDistance=fog_cylindrical_distance(Position);vertexColor=minecraft_mix_light(Light0_Direction,Light1_Direction,Normal,Color)*texelFetch(Sampler2,UV2/16,0);texCoord0=UV0;texCoord1=UV1;texCoord2=UV2;if(_6aaf116dfa780a4f(Position.y)<=-2000){vec3 _143707a42f1f0bdf=Position;int _55471531b473c20f=(_6aaf116dfa780a4f(Position.y)+2000)/-1000;_143707a42f1f0bdf.y+=(_55471531b473c20f*1000)+2500;if(_55471531b473c20f==0){sphericalVertexDistance=fog_spherical_distance(_143707a42f1f0bdf);cylindricalVertexDistance=fog_cylindrical_distance(_143707a42f1f0bdf);gl_Position=ProjMat*vec4(_143707a42f1f0bdf,1.0);gl_Position.z*=0.1;}else if(_55471531b473c20f==1){sphericalVertexDistance=fog_spherical_distance(_143707a42f1f0bdf);cylindricalVertexDistance=fog_cylindrical_distance(_143707a42f1f0bdf);vertexColor.a=0.25;gl_Position=ProjMat*ModelViewMat*vec4(_143707a42f1f0bdf,1.0);}else if(_55471531b473c20f==2){sphericalVertexDistance=fog_spherical_distance(_143707a42f1f0bdf);cylindricalVertexDistance=fog_cylindrical_distance(_143707a42f1f0bdf);vertexColor.a=0.5;gl_Position=ProjMat*ModelViewMat*vec4(_143707a42f1f0bdf,1.0);}else if(_55471531b473c20f==3){sphericalVertexDistance=fog_spherical_distance(_143707a42f1f0bdf);cylindricalVertexDistance=fog_cylindrical_distance(_143707a42f1f0bdf);vertexColor.a=0.75;gl_Position=ProjMat*ModelViewMat*vec4(_143707a42f1f0bdf,1.0);}return;}ivec4 _f55e3202a3bc91f0=ivec4(Color*255);if(_f55e3202a3bc91f0==ivec4(0,0,2,255)){gl_Position.z=0;if(ModelViewMat[3][2]==-11000.0){vertexColor=vec4(0);}else{vertexColor=vec4(0.0,0.0,0.0,1.0);}return;}}
