#version 330
#moj_import<minecraft:fog.glsl>
#moj_import<minecraft:dynamictransforms.glsl>
#moj_import<minecraft:globals.glsl>
#moj_import<counterneft_inferno_palette.glsl>
flat in int cn_first_person_guard;
in vec2 cn_c4_wave_uv;
uniform sampler2D Sampler0;in float sphericalVertexDistance;in float cylindricalVertexDistance;in vec4 vertexColor;in vec2 texCoord0;in vec2 texCoord1;flat in int cn_inferno_kind;flat in int cn_inferno_palette_mode;in float cn_inferno_flame_height;out vec4 fragColor;
void main(){
    // Orthographic inventory/player-preview renders must stay untouched.
    if(cn_first_person_guard==2)discard;
    if(cn_first_person_guard==1){fragColor=vec4(0.0,0.0,0.0,1.0);return;}
    vec4 sampleColor=texture(Sampler0,texCoord0);
    vec4 color=sampleColor*vertexColor*ColorModulator;
    if(cn_inferno_kind==5){
        // Circumferential width changes with latitude. A constant-width card
        // overlaps its neighbours near the poles; clip to shared radial edges.
        if(cn_inferno_palette_mode<4){
            float a=-1.57079632679+float(cn_inferno_palette_mode)*0.78539816339;
            float b=a+0.78539816339;
            float width=mix(max(0.0,cos(a)),max(0.0,cos(b)),cn_c4_wave_uv.y)/max(cos(a),cos(b));
            if(abs(cn_c4_wave_uv.x*2.0-1.0)>width)discard;
        }
        float roll=0.86+0.14*cos(cn_c4_wave_uv.x*25.132741+cn_c4_wave_uv.y*12.0);
        float curtain=(0.65+0.35*pow(sin(cn_c4_wave_uv.y*3.141593),2.0))*roll;
        color=vec4(vec3(0.902,0.933,0.914),vertexColor.a*curtain)*ColorModulator;
    }
    if(cn_inferno_kind==1){
        // RG is clock metadata. B is the generated flame's luminance, A its actual
        // silhouette. Never discard the texture alpha: that would draw solid rectangles.
        bool ct=cn_inferno_palette_mode%2==1;
        float heat=0.66+0.30*sampleColor.b;
        vec3 fire=ct?cn_inferno_ct_flame_color(heat):cn_inferno_t_color(heat);
        if(cn_inferno_palette_mode>=2){
            // Cold color is a visible basal fringe on OUTER patches, never an
            // entire identical blue tongue or a cold island in the ignition core.
            float accent=(1.0-smoothstep(0.06,0.46,cn_inferno_flame_height))
                *(1.0-smoothstep(0.70,0.96,sampleColor.b))*0.95;
            vec3 cold=ct?cn_inferno_ct_color(0.405+0.025*sampleColor.b):cn_inferno_t_color(0.49+0.04*sampleColor.b);
            // Source2 adds an emissive companion; Minecraft uses alpha blending.
            // Bounded exposure compensation, not a global change to item blending.
            cold=min(vec3(1.0),cold*(ct?1.05:1.35));
            fire=mix(fire,cold,accent);
        }
        color=vec4(fire,sampleColor.a*vertexColor.a)*ColorModulator;
    }
    if(cn_inferno_kind==4){
        float lum=sampleColor.b;
        float age=cn_inferno_flame_height;
        if(cn_inferno_palette_mode==0){
            vec3 fire=mix(vec3(1.0,0.26,0.015),vec3(1.0,0.98,0.76),smoothstep(0.20,0.90,lum));
            fire=mix(vec3(0.16,0.35,1.0),fire,smoothstep(0.0,0.23,age));
            color=vec4(fire,sampleColor.a)*ColorModulator;
        }else{
            float fade=smoothstep(0.0,0.07,age)*(1.0-smoothstep(0.45,1.0,age));
            vec3 fire;
            if(cn_inferno_palette_mode==5){
                // Existing native 24px rolling silhouette, emissive golden edge
                // and a yellow-white core. No black/blue smoke in the first ball.
                // The six lobes hand over to the mushroom before fading out.
                float hot=smoothstep(0.12,0.82,lum);
                vec3 gold=mix(vec3(1.0,0.52,0.015),vec3(1.0,0.82,0.06),hot);
                fire=mix(gold,vec3(1.0,1.0,0.72),smoothstep(0.48,0.94,lum));
                fire=mix(fire,vec3(1.0,0.44,0.025),0.32*smoothstep(0.42,1.0,age));
                fade=(1.0-smoothstep(0.38,1.0,age))*(0.78+0.22*hot);
            }else if(cn_inferno_palette_mode==4){
                // Separate C4 heat clock: bright expansion, dark rolling smoke,
                // then translucent smoke. Opacity is PER CARD: many crossed
                // lobes overlap, so 0.46 per card made an almost solid black mass.
                float heat=(1.0-smoothstep(0.18,1.0,vertexColor.r))*smoothstep(0.10,0.85,lum);
                vec3 hot=mix(vec3(0.90,0.17,0.012),vec3(1.0,0.97,0.72),smoothstep(0.38,0.88,heat));
                fire=mix(vec3(0.035,0.030,0.027),hot,heat);
                float smokeAlpha=mix(0.11,0.19,smoothstep(0.15,0.85,lum));
                fade=(1.0-smoothstep(0.42,1.0,age))*mix(smokeAlpha,0.95,smoothstep(0.08,0.55,heat));
                fade*=smoothstep(age*0.30,age*0.30+0.16,lum+0.12);
            }else if(cn_inferno_palette_mode==3){
                // HE heat fades before its smoke. Source gradients end at
                // orange (255,77,23), with breakup driven by collection age.
                float heat=(1.0-smoothstep(0.12,1.0,vertexColor.r))*smoothstep(0.18,0.86,lum);
                vec3 hot=mix(vec3(1.0,77.0/255.0,23.0/255.0),vec3(1.0,0.96,0.72),smoothstep(0.6,1.0,heat));
                fire=mix(vec3(0.025,0.018,0.014),hot,heat);
                fade=(1.0-smoothstep(0.5,0.98,age));
                // Break up the silhouette rather than fading a static square.
                fade*=smoothstep(age*0.5,age*0.5+0.15,lum+0.16);
                // Cold HE smoke is translucent; retain the bright hot flash.
                fade*=mix(0.28,1.0,smoothstep(0.08,0.55,heat));
            }else if(cn_inferno_palette_mode==1){
                // Dark opaque smoke and hot pockets share one animated silhouette.
                // CT must not inherit this black soot component.
                float heat=smoothstep(0.38+0.42*age,0.84+0.12*age,lum);
                fire=mix(vec3(0.024,0.017,0.013),mix(vec3(0.85,0.12,0.008),vec3(1.0,0.92,0.54),heat),heat);
            }else{
                fire=mix(cn_inferno_ct_color(0.415),vec3(1.0,0.97,0.79),smoothstep(0.16,0.73,lum));
            }
            color=vec4(fire,sampleColor.a*fade)*ColorModulator;
        }
    }
    if(cn_inferno_kind==3){
        // Disjoint .25/.5 squares already merged and clipped to the fire on the server.
        // A constant alpha per plane avoids both atlas-corner and vertex-index dependencies.
        color=vec4(vertexColor.rgb,vertexColor.a*0.46)*ColorModulator;
    }else if(cn_inferno_kind==2){
        color.a*=0.46;
    }
    if(color.a<(cn_inferno_kind!=0?0.003:0.1))discard;
    fragColor=apply_fog(color,sphericalVertexDistance,cylindricalVertexDistance,FogEnvironmentalStart,FogEnvironmentalEnd,FogRenderDistanceStart,FogRenderDistanceEnd,FogColor);
}
