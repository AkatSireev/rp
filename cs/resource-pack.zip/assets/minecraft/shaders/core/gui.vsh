#version 330

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl with CounterNeft GUI coordinates.
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

in vec3 Position;
in vec4 Color;

out vec4 vertexColor;
out vec2 cnGuiPos;
out vec2 cnGuiSize;

void main() {
    vec4 clipPosition = ProjMat * ModelViewMat * vec4(Position, 1.0);
    gl_Position = clipPosition;

    vertexColor = Color;
    cnGuiSize = vec2(abs(2.0 / ProjMat[0][0]), abs(2.0 / ProjMat[1][1]));
    vec2 ndc = clipPosition.xy / clipPosition.w;
    cnGuiPos = vec2((ndc.x + 1.0) * 0.5 * cnGuiSize.x,
                    (1.0 - ndc.y) * 0.5 * cnGuiSize.y);
}
