#version 330
#moj_import <minecraft:globals.glsl>

layout(std140) uniform Projection {
    mat4 ProjMat;
};

vec4 projection_from_position(vec4 position) {
    vec4 projection = position * 0.5;
    projection.xy = vec2(projection.x + projection.w, projection.y + projection.w);
    projection.zw = position.zw;
    return projection;
}

// Client 1.21.11: Globals.GameTime=(worldAge % 24000 + partialTick)/24000.
// Only this viewer receives negative ages. Real instance time/daylight is not
// modified. Positive ages and orthographic GUI projections pass through intact.
float cn_scope_fovy(int level, float normalFovy) {
    if (level == 0) return normalFovy;
    float sourceHorizontal = level == 1 ? 40.0 : 10.0;
    return 2.0 * atan(tan(radians(sourceHorizontal) * 0.5) * 0.75);
}
mat4 cn_scope_projection(mat4 raw) {
    float signal = GameTime * 24000.0 + 22000.0;
    if (signal < 0.0 || signal >= 1800.0 || abs(raw[3][3]) > 0.001) return raw;
    int code = int(floor(signal / 100.0));
    float age = mod(signal, 100.0);
    if (age > 90.0) return raw;
    int pair = code / 2;
    int fromLevel = pair / 3;
    int toLevel = pair % 3;
    float duration = code % 2 == 1 ? 2.0 : 1.0;
    float baseFovy = 2.0 * atan(1.0 / raw[1][1]);
    float fovy = mix(cn_scope_fovy(fromLevel, baseFovy), cn_scope_fovy(toLevel, baseFovy), smoothstep(0.0, duration, age));
    float scale = (1.0 / tan(fovy * 0.5)) / raw[1][1];
    raw[0][0] *= scale;
    raw[1][1] *= scale;
    return raw;
}
// Self reference is intentionally not recursively expanded by the preprocessor.
#define ProjMat cn_scope_projection(ProjMat)
