// Marker + reserved texture signature isolate inferno from ordinary item tints.
// Native 8px ground / 24px ignition silhouettes on crossed cards; no cube geometry.
// Display yaw/pitch = 0, x/z scale <= 1, y scale = 1. Position is camera-relative
// world space in 1.21.11's item pipeline; the view rotation is in ModelViewMat.
// Do not reuse the renewing patch path on billboards or scaled-Y displays.
// The R=236 ignition column has static geometry and permits interpolated Y scale.
uniform sampler2D Sampler0;
flat out int cn_inferno_kind;
flat out int cn_inferno_palette_mode;
out float cn_inferno_flame_height;
out vec2 cn_c4_wave_uv;
#moj_import<counterneft_inferno_palette.glsl>
// Valve's molotov_groundfire_climbingoutline: normalized-age ALPHA (field 7),
// depot 2347770 / manifest 6313884916170234593. This is not a height curve.
// Numeric knots/tangents are pinned and checked by inferno-particle-profile.test.mjs.
const vec3 cn_inferno_alpha_knots[9]=vec3[9](
    vec3(0.0,0.0,2.793104),
    vec3(0.072321,0.202,5.438571),
    vec3(0.139654,0.75952,3.199901),
    vec3(0.321704,1.0,0.135),
    vec3(0.498765,0.808,-2.018985),
    vec3(0.640914,0.35552,-2.487857),
    vec3(0.778074,0.11312,-1.096615),
    vec3(0.965111,0.0,-0.50949),
    vec3(1.0001,0.0,0.0)
);
float cn_inferno_flame_alpha(float age) {
    for(int i=0;i<8;i++) {
        vec3 a=cn_inferno_alpha_knots[i],b=cn_inferno_alpha_knots[i+1];
        if(age<=b.x) {
            float span=b.x-a.x,t=clamp((age-a.x)/span,0.0,1.0);
            float t2=t*t,t3=t2*t;
            return clamp((2.0*t3-3.0*t2+1.0)*a.y+(t3-2.0*t2+t)*span*a.z
                +(-2.0*t3+3.0*t2)*b.y+(t3-t2)*span*b.z,0.0,1.0);
        }
    }
    return 0.0;
}
// Stable per-birth pseudo-randomness. No sin/hash precision dependence on world position.
float cn_inferno_random(float seed) {
    vec3 p=fract(vec3(seed)*vec3(0.1031,0.1030,0.0973));
    p+=dot(p,p.yzx+33.33);
    return fract((p.x+p.y)*p.z);
}
bool cn_scorch_material() {
    // Atlas samples identify the material ONLY, never its four coverage corners.
    // Preserve isolation from ordinary items whose tint happens to contain R=237.
    ivec2 size=textureSize(Sampler0,0),pixel=ivec2(floor(UV0*vec2(size)));
    for(int y=-1;y<=1;y++)for(int x=-1;x<=1;x++){
        vec3 marker=texelFetch(Sampler0,clamp(pixel+ivec2(x,y),ivec2(0),size-1),0).rgb*255.0;
        if(abs(marker.r-32.0)<0.5 && marker.g>=125.0 && marker.g<=195.0 && marker.b>=189.0)return true;
    }
    return false;
}
float cn_scorch_square_alpha(vec4 tint) {
    // Uniform per-square opacity. No UV, vertex-order or interpolated corner protocol.
    return clamp(floor(tint.g*255.0+0.5)/15.0,0.0,1.0);
}
bool cn_inferno_vertex() {
    ivec4 tag=ivec4(floor(Color*255.0+0.5));
    cn_inferno_kind=0;
    cn_inferno_palette_mode=0;
    cn_inferno_flame_height=0.0;
    cn_c4_wave_uv=vec2(0.0);
    if(tag.a!=255)return false;
    if(tag.r==230 && tag.g==0){
        // Short yellow-white C4 ignition sphere, separate from its smoky mushroom.
        cn_inferno_kind=4;cn_inferno_palette_mode=5;
        cn_inferno_flame_height=float(tag.b)/255.0;
        vertexColor=vec4(1.0);return true;
    }
    if(tag.r==231 && tag.g==0){
        // Airborne Molotov uses ordinary authored RGBA, not the ground flame
        // clock/palette. Preserve wispy alpha below vanilla's .1 cutoff.
        cn_inferno_kind=6;vertexColor=vec4(1.0,1.0,1.0,float(tag.b)/255.0);return true;
    }
    if(tag.r==232 && tag.g<=4 && tag.b<=15){
        cn_inferno_kind=5;
        cn_inferno_palette_mode=tag.g;
        cn_c4_wave_uv=textureLod(Sampler0,UV0,0.0).rg;
        // Keep the front visible until it reaches its configured extent. A
        // linear age fade made the farthest recipients see no wave at all.
        vertexColor=vec4(1.0,1.0,1.0,0.14*(1.0-smoothstep(0.86,1.0,float(tag.b)/15.0)));return true;
    }
    if(tag.r==233){
        cn_inferno_kind=4;cn_inferno_palette_mode=4;
        cn_inferno_flame_height=float(tag.b)/255.0;
        vertexColor=vec4(float(tag.g)/255.0,1.0,1.0,1.0);return true;
    }
    if(tag.r==234){
        // HE: absolute 0..750ms heat clock (G), independent smoke life (B).
        cn_inferno_kind=4;cn_inferno_palette_mode=3;
        cn_inferno_flame_height=float(tag.b)/255.0;
        vertexColor=vec4(float(tag.g)/255.0,1.0,1.0,1.0);return true;
    }
    if(tag.r==235 && tag.g<=3){
        // 0: captured viewmodel lighter; 1/2: T/CT impact cloud. Preserve the
        // camera projection already installed by the viewmodel shader path.
        cn_inferno_kind=4;cn_inferno_palette_mode=tag.g;
        cn_inferno_flame_height=tag.g==0?step(0.5,textureLod(Sampler0,UV0,0.0).b):float(tag.b)/255.0;
        vertexColor=vec4(1.0);return true;
    }
    if(tag.r==237 && tag.g<=15 && tag.b==0 && Normal.y>0.99 && cn_scorch_material()){
        cn_inferno_kind=3;
        vertexColor=vec4(0.02,0.015,0.012,cn_scorch_square_alpha(Color));
        // Isolated decal depth bias; the real plane is above the canonical floor.
        gl_Position=ProjMat*ModelViewMat*vec4(Position,1.0);
        gl_Position.z-=0.000002*gl_Position.w;
        return true;
    }
    if(tag.r==238 && tag.g>=0 && tag.g<8 && tag.b<=15){
        cn_inferno_kind=2;
        vertexColor=vec4(0.075,0.059,0.055,float(tag.b)/15.0);
        return true;
    }
    if(tag.r==236 && tag.g%128<4 && tag.b<=15){
        cn_inferno_kind=1;
        cn_inferno_palette_mode=tag.g>=128?1:0;
        cn_inferno_flame_height=step(0.5,textureLod(Sampler0,UV0,0.0).b);
        vec2 clock=textureLod(Sampler0,UV0,0.0).rg*2.0-1.0;
        float member=float(tag.g%128),phase=atan(clock.y,clock.x);
        float pulse=0.85+0.15*sin(phase*8.0+member*0.4);
        float heat=0.94-0.12*member/3.0;
        vec3 color=tag.g>=128?cn_inferno_ct_flame_color(heat):cn_inferno_t_color(heat);
        vertexColor=vec4(color,float(tag.b)/15.0*pulse);
        // All motion is one bounded display transform, interpolated by Minecraft.
        // No phase-dependent displacement may escape its proved ceiling envelope.
        return true;
    }
    if(tag.r<240 || tag.r>255 || tag.g%32>=30)return false;
    cn_inferno_kind=1;
    // Scope uses GameTime as a control channel. The animated texture supplies
    // a separate circular clock; interpolation across the loop stays continuous.
    vec3 marker=textureLod(Sampler0,UV0,0.0).rgb;
    cn_inferno_flame_height=step(0.5,marker.b);
    vec2 clock=marker.rg*2.0-1.0;
    float cycle=atan(clock.y,clock.x)/6.28318530718;
    float id=float(tag.g%32),variant=float((tag.r-240)/4);
    float horizontalScale=float((tag.r-240)%4)/3.0;
    bool ct=tag.g>=128;
    bool bridge=(tag.g%64)>=32;
    bool low=id<24.0 && !bridge;
    bool basal=(tag.g%128)>=64 && id<24.0 && !bridge;
    cn_inferno_palette_mode=(ct?1:0)+(basal?2:0);
    // A 12.8-second clock contains eight births per slot. Wrap the birth number
    // independently: the atlas seam never changes a visible particle's origin.
    float emitter=id;
    float emission=fract(cycle)*8.0+emitter*0.61803398875+variant*0.217;
    float birth=mod(floor(emission),8.0),age=fract(emission)*1.6;
    float seed=emitter*71.0+variant*313.0+birth*997.0;
    float r0=cn_inferno_random(seed+1.0),r1=cn_inferno_random(seed+2.0);
    float r2=cn_inferno_random(seed+3.0),r3=cn_inferno_random(seed+4.0);
    // Longer low-fire duty cycle, same number of cards/births. The climbing
    // lifetime remains pinned; low lifetime is a Minecraft visual calibration.
    float lifetime=low?0.85+0.50*r0:0.45+0.55*r0;
    float p=clamp(age/lifetime,0.0,1.0);
    float rise=float(tag.b/16)/15.0*2.415;
    float opacity=float(tag.b%16)/15.0;
    // Every card is one complete tongue, not sections of floating cubes.
    float pulse=cn_inferno_flame_alpha(p);
    // Recovered climbing initializer 40--120 units/s, +200 units/s^2, cap 100 units/s.
    // Normalize this capped path to the proved Minecraft headroom; do not exceed fit.
    float initial=min(100.0,40.0+80.0*r1);
    float capTime=(100.0-initial)/200.0;
    float t=p*lifetime,accelerating=min(t,capTime);
    float travelled=initial*accelerating+100.0*accelerating*accelerating+100.0*max(0.0,t-capTime);
    float full=initial*capTime+100.0*capTime*capTime+100.0*(lifetime-capTime);
    // Six existing root/near-root cards bridge the height gap; no new entities.
    float heightFactor=0.45+0.55*r2;
    // Stretch the top only. The flame always remains attached to the floor and
    // never exceeds BASE_HEIGHT + fitted rise, even underneath a low ceiling.
    float extra=min(0.071,rise*0.20);
    float lift=low?0.0:max(0.0,rise-extra)*heightFactor*min(1.0,travelled/(full*0.65));
    float sway=0.04*horizontalScale*sin(p*6.28318530718+id*0.5);
    float heading=r2*6.28318530718;
    // Exterior accents keep their outward plan anchor; birth jitter must not
    // drag a blue/violet tongue through the warm inside of an outer patch.
    vec2 origin=basal?vec2(0.0):(vec2(r1,r2)*2.0-1.0)*0.08*horizontalScale;
    vec3 position=Position+vec3(origin.x+cos(heading+p*1.1)*sway,0.0,origin.y+sin(heading+p*1.1)*sway);
    float wave=0.5+0.5*sin(p*6.28318530718);
    float side=0.284;
    float stretch=0.45+0.55*smoothstep(0.0,0.4,p);
    // B encodes the local top/bottom vertex. Stretch about the bottom, never about camera/world Y.
    position.y+=((stretch-1.0)*side+extra*smoothstep(0.0,0.4,p)+lift)*step(0.5,marker.b);
    // Both layers die before re-sampling their origin. No permanent bright grid.
    float envelope=pulse*(low?0.96:0.90);
    float heat=low?(ct?0.62+0.18*pulse:0.68+0.14*pulse):0.68+0.26*pulse;
    vec3 color=ct?cn_inferno_ct_flame_color(heat):cn_inferno_t_color(heat);
    // Do not multiply violet by orange: direct Source LUT output remains visibly violet.
    // CT outline uses its own cyan-to-warm lookup, rather than inventing a purple CT palette.
    if(basal)color=ct?cn_inferno_ct_color(0.405+0.025*wave):cn_inferno_t_color(0.49+0.04*wave);
    vertexColor=vec4(color,opacity*envelope);
    gl_Position=ProjMat*ModelViewMat*vec4(position,1.0);
    sphericalVertexDistance=fog_spherical_distance(position);
    cylindricalVertexDistance=fog_cylindrical_distance(position);
    return true;
}
