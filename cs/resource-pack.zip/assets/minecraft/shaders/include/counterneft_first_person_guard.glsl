// Reserved unshaded item tint 0x010713. The item model selects HEAD + view_entity;
// LevelRenderer omits the camera entity in first person (except sleeping, not a CS state).
// No distance/FOV heuristic: camera collision at a wall cannot shrink this quad.
flat out int cn_first_person_guard;
bool cn_first_person_guard_vertex() {
    cn_first_person_guard = 0;
    if (!all(equal(ivec4(round(Color * 255.0)), ivec4(1, 7, 19, 255)))) return false;
    cn_first_person_guard = abs(ProjMat[3][3]) < 0.001 ? 1 : 2;
    int corner = gl_VertexID % 4;
    // CCW indexed quad: 0,1,2 and 2,3,0. No depth, near-plane or FOV dependency.
    vec2 p = vec2(corner < 2 ? -1.0 : 1.0, (corner == 0 || corner == 3) ? 1.0 : -1.0);
    gl_Position = vec4(p, -1.0, 1.0);
    return true;
}
