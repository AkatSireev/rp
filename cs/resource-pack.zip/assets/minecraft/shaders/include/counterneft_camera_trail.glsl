// Layer 4 is a camera-space ballistic trail. Unlike the foreground weapon
// (layer 0), retain real projected depth: a wall must still occlude the trail.
bool counterneft_camera_trail(vec3 position, out vec3 cameraPosition) {
    if (position.y > -7000.0 && position.y < -6000.0) {
        cameraPosition = position + vec3(0.0, 6500.0, 0.0);
        return true;
    }
    return false;
}
