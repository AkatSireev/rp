#version 330

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};

in vec4 vertexColor;
in vec2 ahGuiPos;
in vec2 ahGuiSize;

out vec4 fragColor;

const bool AH_DIALOG_FOCUS_ENABLED = true;
const bool AH_DIALOG_FOCUS_DEBUG = false;
const float AH_DIALOG_FOCUS_HALF_WIDTH = 230.5;
const float AH_DIALOG_CONTENT_HEIGHT = 1682.0;
const float AH_DIALOG_FOCUS_MARGIN_Y = 96.0;
const float AH_DIALOG_HEADER_HEIGHT = 33.0;
const float AH_DIALOG_FOOTER_HEIGHT = 33.0;
const float AH_DIALOG_CONTENT_MARGIN_TOP = 30.0;
const float AH_DIALOG_FOCUS_MIN_RGB = 0.98;
const float AH_DIALOG_FOCUS_MIN_ALPHA = 0.25;

bool ah_is_dialog_focus(vec4 color) {
    if (!AH_DIALOG_FOCUS_ENABLED) return false;
    bool nearWhite = color.r >= AH_DIALOG_FOCUS_MIN_RGB
        && color.g >= AH_DIALOG_FOCUS_MIN_RGB
        && color.b >= AH_DIALOG_FOCUS_MIN_RGB
        && color.a >= AH_DIALOG_FOCUS_MIN_ALPHA;
    vec2 center = ahGuiSize * 0.5;
    float visibleBodyHeight = min(AH_DIALOG_CONTENT_HEIGHT,
        max(1.0, ahGuiSize.y - AH_DIALOG_HEADER_HEIGHT - AH_DIALOG_FOOTER_HEIGHT));
    float bodyTop = min(AH_DIALOG_HEADER_HEIGHT + AH_DIALOG_CONTENT_MARGIN_TOP,
        ahGuiSize.y - AH_DIALOG_FOOTER_HEIGHT - visibleBodyHeight);
    bool insideMeasuredDialog = abs(ahGuiPos.x - center.x) <= AH_DIALOG_FOCUS_HALF_WIDTH
        && ahGuiPos.y >= bodyTop - AH_DIALOG_FOCUS_MARGIN_Y
        && ahGuiPos.y <= bodyTop + visibleBodyHeight + AH_DIALOG_FOCUS_MARGIN_Y;
    return nearWhite && insideMeasuredDialog;
}

void main() {
    vec4 color = vertexColor;
    if (color.a == 0.0) discard;
    vec4 outputColor = color * ColorModulator;
    if (ah_is_dialog_focus(outputColor)) {
        if (AH_DIALOG_FOCUS_DEBUG) {
            fragColor = vec4(1.0, 0.0, 1.0, 1.0);
            return;
        }
        discard;
    }
    fragColor = outputColor;
}
