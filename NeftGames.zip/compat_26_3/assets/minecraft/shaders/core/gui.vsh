#version 330
#extension GL_ARB_separate_shader_objects : require

// 26.3-compatible GUI shader overlay.
// DynamicTransforms field order matches Minecraft 26.3.
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;

layout(location = 0) out vec4 vertexColor;
layout(location = 1) out vec2 ahGuiPos;
layout(location = 2) out vec2 ahGuiSize;

void main() {
    vec4 clipPosition = ProjMat * ModelViewMat * vec4(Position, 1.0);
    gl_Position = clipPosition;
    vertexColor = Color;
    ahGuiSize = vec2(abs(2.0 / ProjMat[0][0]), abs(2.0 / ProjMat[1][1]));
    vec2 ndc = clipPosition.xy / clipPosition.w;
    ahGuiPos = vec2((ndc.x + 1.0) * 0.5 * ahGuiSize.x,
                    (1.0 - ndc.y) * 0.5 * ahGuiSize.y);
}
